#### Dear beloved Batchlinks user,

I want to share with you that I have lost interest in this project/repo. It was a time when I was fully invested in it, spending countless hours fixing bugs, adding new features, and learning Python/Markdown. I remember the excitement of refreshing the notification page on Github to find a new bug report or feature request. It was an addicting experience, and I enjoyed it more than my college studies.

But unfortunately, things have changed, and my mood and interests shift rapidly. I have been into different things throughout my life, such as game development, graphic design, video editing, music creation, gaming, and more. Even though I loved generating images with AI during the early days of stable diffusion, I rarely do it now, since my focus has shifted into this project.

Despite my change in interests, I want to emphasize that I don't want to abandon this project. I have made many friends through this project, and it holds a special place in my heart. However, I just can't continue to give it the same level of attention and dedication that it deserves. I might still do some small bug fixes, but for adding features, maybe not.

I will miss those days of working on this project, but I'm excited to explore new interests in gaming, video editing, and many others. I want to thank camenduru, machiavel, 7743, NUROISEA, NoCrypt, and many other people who supported me on various Discord servers, github issues, and many other places. Also thanks to everyone who has contributed to this project, whether by reporting bug, requesting features, pull request, and many others. And lastly, thank YOU for using this tool. It might just helps you a little, but every single user means A LOT to me.

I hope this continues to thrive and helps people in the future.💖

Best regards,<br/>
MJ